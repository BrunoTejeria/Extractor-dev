

from src.modules.m_execute.execute import main
from src.modules.m_config.config import Config



if __name__ == '__main__':
    main()
