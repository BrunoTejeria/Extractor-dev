pip install -r requirements.txt
echo 'Requirements instaladas'